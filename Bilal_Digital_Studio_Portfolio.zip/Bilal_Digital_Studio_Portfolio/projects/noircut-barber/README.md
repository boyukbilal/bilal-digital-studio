# NoirCut Barber Club — Portfolio Demo

Erkek kuaförü / barber shop müşterilerine göstermek için hazırlanmış responsive tek sayfalık demo.

## İçerik
- Hero ve marka alanı
- Hizmet kartları
- Stil galerisi
- Berber profilleri
- Fiyat listesi
- Müşteri yorumları
- Tarih ve saat seçmeli randevu formu
- WhatsApp butonu
- Mobil menü
- Yerel SVG demo görselleri

## Çalıştırma
`index.html` dosyasını tarayıcıda açmanız yeterli.

## Gerçek müşteriye uyarlarken
- Marka adı, logo ve renkleri değiştirin.
- Gerçek işletme fotoğraflarını ekleyin.
- Fiyatları güncelleyin.
- Telefon, WhatsApp, adres ve e-posta bilgilerini değiştirin.
- Randevu formunu WhatsApp, Google Calendar, Calendly veya özel backend'e bağlayın.
- Google Maps konumu ve Instagram bağlantısı ekleyin.
