const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

menuToggle?.addEventListener('click', () => {
  const open = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});

document.getElementById('year').textContent = new Date().getFullYear();

function handleForm(event) {
  event.preventDefault();
  const note = document.getElementById('form-note');
  note.textContent = 'Demo formu çalışıyor. Gerçek projede bu alan WhatsApp, e-posta veya CRM sistemine bağlanabilir.';
  return false;
}
