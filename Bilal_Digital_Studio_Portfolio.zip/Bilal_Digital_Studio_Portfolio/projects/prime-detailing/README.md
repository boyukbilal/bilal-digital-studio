# Prime Detailing Studio — Portfolio Demo

Bu proje, oto detailing / araç bakım işletmelerine sunulabilecek tek sayfalık demo web sitesidir.

## Dosyalar
- `index.html` — ana sayfa
- `styles.css` — tüm tasarım ve responsive yapı
- `script.js` — mobil menü ve demo form davranışı
- `assets/` — yerel SVG görseller

## Çalıştırma
1. Klasörü aç.
2. `index.html` dosyasına çift tıkla.
3. Tarayıcıda doğrudan çalışır.

## Gerçek müşteriye uyarlarken
- Marka adını değiştir.
- Telefon / WhatsApp numarasını değiştir.
- Adres ve e-posta bilgilerini değiştir.
- Demo fiyatlarını müşterinin gerçek fiyatlarıyla güncelle.
- SVG görselleri gerçek işletme fotoğraflarıyla değiştir.
- Google Maps iframe veya gerçek konum linki ekle.
- Formu Formspree, Netlify Forms, WhatsApp veya bir backend servisine bağla.

## Satış sunumu için önerilen kapsam
- Mobil uyumlu tek sayfa site
- WhatsApp randevu butonu
- Hizmet kartları
- Paket/fiyat alanı
- Önce-sonra galerisi
- Müşteri yorumları
- İletişim formu
- Temel SEO meta bilgileri

Bu demo tamamen statiktir ve herhangi bir framework gerektirmez.
